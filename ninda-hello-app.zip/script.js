document.getElementsByTagName("h1")[0].style.fontSize = "6vw";

function showMessage() {
  document.getElementById("message").textContent = "✨ You're doing great, Ninda!";
}
